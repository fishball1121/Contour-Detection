public class EmptySymTableException extends Exception {

}
