///////////////////////////////////////////////////////////
// Title: 				Programming Assignment 5
// Main Class File: 	P5.java
// Files: 				DuplicateSymException.java
// Semester: 			CS 536 Fall 2015
//
// Author: 				Yuting Liu
// Email:				liu487@wisc.edu
// CS Login: 			yuting
// Lecturer: 			Aws Albarghouthi
//////////////////////////////////////////////////////////

public class DuplicateSymException extends Exception {

}
